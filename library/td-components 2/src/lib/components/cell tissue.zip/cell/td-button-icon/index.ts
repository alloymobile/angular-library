// src/lib/components/cell/td-button-icon/index.ts

export * from './td-button-icon.model';
export * from './td-button-icon';
