// src/lib/components/cell/td-media/index.ts

export * from './td-media.model';
export * from './td-media';
