// src/lib/components/cell/td-link-icon/index.ts

export * from './td-link-icon.model';
export * from './td-link-icon';
