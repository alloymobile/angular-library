// src/lib/components/cell/td-button-submit/index.ts

export * from './td-button-submit.model';
export * from './td-button-submit';
