// src/lib/components/cell/td-link/index.ts

export * from './td-link.model';
export * from './td-link';
