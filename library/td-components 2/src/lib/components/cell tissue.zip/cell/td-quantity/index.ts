// src/lib/components/cell/td-quantity/index.ts

export * from './td-quantity.model';
export * from './td-quantity';
