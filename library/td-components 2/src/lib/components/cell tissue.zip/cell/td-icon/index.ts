// src/lib/components/cell/td-icon/index.ts

export * from './td-icon.model';
export * from './td-icon';
