package com.td.plra.service.primerate.client;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Client for fetching prime rate from an external third-party API.
 * <p>
 * Uses OAuth2 client credentials flow:
 * <ol>
 *   <li>POST to token URL with client_id + client_secret → bearer token</li>
 *   <li>GET prime rate endpoint with bearer token → prime rate data</li>
 * </ol>
 * </p>
 *
 * <b>Configuration:</b> All URLs and credentials are read from {@code application.yaml}
 * under the {@code plra.prime.api.*} namespace. In production, the client secret
 * should be sourced from HashiCorp Vault.
 */
@Slf4j
@Component
public class ExternalPrimeRateClient {

    @Value("${plra.prime.api.url}")
    private String primeApiUrl;

    @Value("${plra.prime.api.token-url}")
    private String tokenUrl;

    @Value("${plra.prime.api.client-id}")
    private String clientId;

    @Value("${plra.prime.api.client-secret}")
    private String clientSecret;

    private final RestTemplate restTemplate;

    public ExternalPrimeRateClient() {
        this.restTemplate = new RestTemplate();
    }

    /**
     * Fetches the current prime rate from the external API.
     *
     * @return PrimeRateResponse with rate, effectiveDate, source, description
     * @throws RuntimeException if token acquisition or API call fails
     */
    public PrimeRateResponse fetchPrimeRate() {
        String token = obtainAccessToken();
        return callPrimeEndpoint(token);
    }

    private String obtainAccessToken() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        MultiValueMap<String, String> body = new LinkedMultiValueMap<>();
        body.add("grant_type", "client_credentials");
        body.add("client_id", clientId);
        body.add("client_secret", clientSecret);

        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(body, headers);

        try {
            ResponseEntity<TokenResponse> response = restTemplate.postForEntity(
                    tokenUrl, request, TokenResponse.class);

            if (response.getBody() != null) {
                log.debug("Access token obtained from {}", tokenUrl);
                return response.getBody().getAccessToken();
            }
            throw new RuntimeException("Empty token response from " + tokenUrl);
        } catch (Exception e) {
            log.error("Failed to obtain access token from {}: {}", tokenUrl, e.getMessage());
            throw new RuntimeException("Failed to obtain prime API access token", e);
        }
    }

    private PrimeRateResponse callPrimeEndpoint(String token) {
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(token);
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<Void> request = new HttpEntity<>(headers);

        try {
            ResponseEntity<PrimeRateResponse> response = restTemplate.exchange(
                    primeApiUrl, HttpMethod.GET, request, PrimeRateResponse.class);

            if (response.getBody() != null) {
                log.info("Prime rate fetched: rate={}, effectiveDate={}",
                        response.getBody().getRate(), response.getBody().getEffectiveDate());
                return response.getBody();
            }
            throw new RuntimeException("Empty response from prime rate API");
        } catch (Exception e) {
            log.error("Failed to fetch prime rate from {}: {}", primeApiUrl, e.getMessage());
            throw new RuntimeException("Failed to fetch prime rate from external API", e);
        }
    }

    // --- Inner DTOs for external API responses ---

    @Data
    public static class TokenResponse {
        @JsonProperty("access_token")
        private String accessToken;

        @JsonProperty("token_type")
        private String tokenType;

        @JsonProperty("expires_in")
        private int expiresIn;
    }

    @Data
    public static class PrimeRateResponse {
        @JsonProperty("rate")
        private BigDecimal rate;

        @JsonProperty("effectiveDate")
        private LocalDate effectiveDate;

        @JsonProperty("source")
        private String source;

        @JsonProperty("description")
        private String description;
    }
}
