package com.td.plra.service.primerate;

import com.querydsl.core.types.dsl.BooleanExpression;
import com.td.plra.application.exception.EntityNotFoundException;
import com.td.plra.application.utils.PageResponse;
import com.td.plra.persistence.entity.PrimeRate;
import com.td.plra.persistence.enums.ActiveStatus;
import com.td.plra.persistence.repository.PrimeRateRepository;
import com.td.plra.service.primerate.binding.PrimeRateBinding;
import com.td.plra.service.primerate.client.ExternalPrimeRateClient;
import com.td.plra.service.primerate.client.ExternalPrimeRateClient.PrimeRateResponse;
import com.td.plra.service.primerate.dto.PrimeRateAdminView;
import com.td.plra.service.primerate.mapper.PrimeRateMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Service layer for Prime Rate operations.
 * <p>
 * Implements a <b>lazy-fetch-and-cache</b> strategy:
 * <ol>
 *   <li>UI calls {@code GET /api/v1/prime/current}</li>
 *   <li>Service checks DB for the active prime rate</li>
 *   <li>If found and {@code FETCHED_ON} is within the staleness window → return cached value</li>
 *   <li>If stale or missing → call external API, store result in DB, return it</li>
 * </ol>
 * </p>
 *
 * <b>Key behaviours:</b>
 * <ul>
 *   <li>Prime rate is universal — applies to ALL products (no Product FK)</li>
 *   <li>No manual create/update/delete — data comes only from the external API</li>
 *   <li>24-hour staleness rule (configurable via {@code plra.prime.staleness-hours})</li>
 *   <li>Graceful fallback: if external API is down, returns stale cached value</li>
 *   <li>Only one active prime rate at a time in the system</li>
 * </ul>
 */
@Slf4j
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class PrimeRateService {

    private static final String ENTITY_NAME = "PrimeRate";

    private final PrimeRateRepository repository;
    private final PrimeRateMapper mapper;
    private final PrimeRateBinding binding;
    private final ExternalPrimeRateClient externalClient;

    @Value("${plra.prime.staleness-hours:24}")
    private int stalenessHours;

    // ============================================================
    // CURRENT (Lazy Fetch & Cache)
    // ============================================================

    /**
     * Get the current prime rate.
     * <p>
     * If a fresh cached value exists (fetched within the staleness window),
     * it is returned immediately. Otherwise, the external API is called,
     * the result is stored, and the new value is returned.
     * </p>
     *
     * @return admin view of the current prime rate
     * @throws RuntimeException if external API is unreachable and no cached value exists
     */
    @Transactional
    public PrimeRateAdminView getCurrent() {
        log.info("Getting current prime rate");

        Optional<PrimeRate> cached = repository
                .findFirstByActiveOrderByFetchedOnDesc(ActiveStatus.Y);

        if (cached.isPresent() && isFresh(cached.get())) {
            log.debug("Returning cached prime rate: id={}, fetchedOn={}",
                    cached.get().getId(), cached.get().getFetchedOn());
            return mapper.toAdminView(cached.get());
        }

        // Stale or missing — fetch from external API
        log.info("Prime rate is {} — fetching from external API",
                cached.isEmpty() ? "missing" : "stale");

        return fetchAndStore(cached.orElse(null));
    }

    // ============================================================
    // READ (Paginated History)
    // ============================================================

    /**
     * Find by ID.
     *
     * @param id prime rate ID
     * @return admin view of the prime rate
     * @throws EntityNotFoundException if no prime rate found with the given ID
     */
    public PrimeRateAdminView findById(Long id) {
        log.debug("Finding prime rate by id={}", id);

        PrimeRate entity = repository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException(ENTITY_NAME, id));

        return mapper.toAdminView(entity);
    }

    /**
     * Find all prime rates with pagination and dynamic filtering.
     *
     * @param params   query parameters from the request
     * @param pageable pagination and sorting configuration
     * @return paginated response of prime rate admin views
     */
    public PageResponse<PrimeRateAdminView> findAll(Map<String, String> params, Pageable pageable) {
        log.debug("Finding all prime rates with params: {}", params);

        BooleanExpression predicate = binding.buildPredicate(params);

        Page<PrimeRate> page;
        if (predicate != null) {
            page = repository.findAll(predicate, pageable);
        } else {
            page = repository.findAll(pageable);
        }

        List<PrimeRateAdminView> content = mapper.toAdminViewList(page.getContent());
        return PageResponse.from(page, content);
    }

    // ============================================================
    // REFRESH (Force Re-fetch)
    // ============================================================

    /**
     * Force a fresh fetch from the external API regardless of staleness.
     *
     * @return admin view of the newly fetched prime rate
     */
    @Transactional
    public PrimeRateAdminView refresh() {
        log.info("Force-refreshing prime rate");

        Optional<PrimeRate> cached = repository
                .findFirstByActiveOrderByFetchedOnDesc(ActiveStatus.Y);

        return fetchAndStore(cached.orElse(null));
    }

    // ============================================================
    // PRIVATE HELPERS
    // ============================================================

    private boolean isFresh(PrimeRate rate) {
        LocalDateTime threshold = LocalDateTime.now().minusHours(stalenessHours);
        return rate.getFetchedOn().isAfter(threshold);
    }

    private PrimeRateAdminView fetchAndStore(PrimeRate staleFallback) {
        try {
            PrimeRateResponse response = externalClient.fetchPrimeRate();

            // Deactivate all previous active records
            List<PrimeRate> previousActive = repository.findByActive(ActiveStatus.Y);
            for (PrimeRate prev : previousActive) {
                prev.setActive(ActiveStatus.N);
                repository.save(prev);
            }

            // Create new cached record
            PrimeRate entity = new PrimeRate();
            entity.setRateValue(response.getRate());
            entity.setEffectiveDate(response.getEffectiveDate());
            entity.setSource(response.getSource());
            entity.setDetail(response.getDescription());
            entity.setActive(ActiveStatus.Y);
            entity.setFetchedOn(LocalDateTime.now());
            entity.setVersion(1);

            entity = repository.save(entity);

            log.info("Stored new prime rate: id={}, rate={}, effectiveDate={}",
                    entity.getId(), entity.getRateValue(), entity.getEffectiveDate());

            return mapper.toAdminView(entity);

        } catch (Exception e) {
            log.error("Failed to fetch prime rate from external API: {}", e.getMessage());

            // Fallback: return stale cached value if available
            if (staleFallback != null) {
                log.warn("Returning stale cached prime rate as fallback: id={}, fetchedOn={}",
                        staleFallback.getId(), staleFallback.getFetchedOn());
                return mapper.toAdminView(staleFallback);
            }

            throw new RuntimeException(
                    "No prime rate available and external API is unreachable", e);
        }
    }
}
