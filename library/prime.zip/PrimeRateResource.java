package com.td.plra.resource;

import com.td.plra.application.utils.ApiResponse;
import com.td.plra.application.utils.PageResponse;
import com.td.plra.service.primerate.PrimeRateService;
import com.td.plra.service.primerate.dto.PrimeRateAdminView;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

import static com.td.plra.application.utils.PaginationUtils.resolvePageable;

/**
 * REST resource for Prime Rate management.
 * <p>
 * Base URL: {@code /api/v1/prime}
 * </p>
 *
 * <b>Endpoints:</b>
 * <pre>
 *   GET    /api/v1/prime/current                → Get current prime rate (lazy-fetch-and-cache)
 *   GET    /api/v1/prime/{id}                   → Get prime rate by ID
 *   GET    /api/v1/prime                        → List prime rates (paginated + filtered)
 *   POST   /api/v1/prime/refresh                → Force re-fetch from external API
 * </pre>
 *
 * <b>Note:</b> This resource is <b>read-only</b>. Prime rate is universal — it applies
 * to all products (ULOC, ILOC). There is no product filter. Data is populated exclusively
 * by the external API via the lazy-fetch-and-cache mechanism in {@link PrimeRateService}.
 */
@Slf4j
@RestController
@RequestMapping("/api/v1/prime")
@RequiredArgsConstructor
@Tag(name = "Prime Rates", description = "Prime rate management — cached from external API, universal for all products")
public class PrimeRateResource {

    private final PrimeRateService service;

    // ============================================================
    // CURRENT (Lazy Fetch & Cache)
    // ============================================================

    @GetMapping("/current")
    @Operation(summary = "Get current prime rate",
            description = "Returns the current prime rate. Prime rate is universal — applies to all products. "
                    + "If the cached value is stale (>24 hours) or missing, "
                    + "the external API is called, the result is stored, and returned. "
                    + "If the external API is unreachable, a stale cached value is returned as fallback.")
    @ApiResponses({
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "200", description = "Current prime rate returned"),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "503", description = "External API unreachable and no cached value available",
                    content = @Content(schema = @Schema(implementation = ApiResponse.class)))
    })
    public ResponseEntity<ApiResponse<PrimeRateAdminView>> getCurrent() {
        log.info("GET /api/v1/prime/current");
        PrimeRateAdminView current = service.getCurrent();
        return ApiResponse.ok(current);
    }

    // ============================================================
    // READ
    // ============================================================

    @GetMapping("/{id}")
    @Operation(summary = "Get prime rate by ID", description = "Retrieves a prime rate by its ID")
    @ApiResponses({
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "200", description = "Prime rate found"),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "404", description = "Prime rate not found")
    })
    public ResponseEntity<ApiResponse<PrimeRateAdminView>> findById(
            @Parameter(description = "Prime Rate ID", required = true)
            @PathVariable Long id) {
        log.debug("GET /api/v1/prime/{}", id);
        PrimeRateAdminView primeRate = service.findById(id);
        return ApiResponse.ok(primeRate);
    }

    @GetMapping
    @Operation(summary = "Get all prime rates",
            description = "Retrieves all cached prime rates with pagination, sorting, and dynamic filtering. "
                    + "Defaults to showing only active rates unless 'active' param is specified.")
    @ApiResponses({
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "200", description = "Prime rates retrieved successfully")
    })
    public ResponseEntity<ApiResponse<PageResponse<PrimeRateAdminView>>> findAll(
            @Parameter(description = "Filter by source (contains, case-insensitive)")
            @RequestParam(name = "source", required = false) String source,

            @Parameter(description = "Filter by active status (Y/N). Defaults to Y.")
            @RequestParam(name = "active", required = false) String active,

            @Parameter(description = "Fetched date from (yyyy-MM-dd)")
            @RequestParam(name = "fetchedFrom", required = false) String fetchedFrom,

            @Parameter(description = "Fetched date to (yyyy-MM-dd)")
            @RequestParam(name = "fetchedTo", required = false) String fetchedTo,

            @Parameter(description = "Effective date from (yyyy-MM-dd)")
            @RequestParam(name = "effectiveDateFrom", required = false) String effectiveDateFrom,

            @Parameter(description = "Effective date to (yyyy-MM-dd)")
            @RequestParam(name = "effectiveDateTo", required = false) String effectiveDateTo,

            @Parameter(description = "Created date from (yyyy-MM-dd)")
            @RequestParam(name = "createdFrom", required = false) String createdFrom,

            @Parameter(description = "Created date to (yyyy-MM-dd)")
            @RequestParam(name = "createdTo", required = false) String createdTo,

            @Parameter(description = "If true, returns all results without pagination")
            @RequestParam(name = "unpaged", required = false, defaultValue = "false") Boolean unpaged,

            @Parameter(hidden = true) @RequestParam Map<String, String> allParams,

            @PageableDefault(size = 20, sort = "fetchedOn", direction = Sort.Direction.DESC) Pageable pageable) {
        log.debug("GET /api/v1/prime with params: {}", allParams);
        Pageable resolvedPageable = resolvePageable(allParams, pageable);
        PageResponse<PrimeRateAdminView> page = service.findAll(allParams, resolvedPageable);
        return ApiResponse.ok(page);
    }

    // ============================================================
    // REFRESH (Force Re-fetch)
    // ============================================================

    @PostMapping("/refresh")
    @Operation(summary = "Force refresh prime rate",
            description = "Forces a fresh fetch from the external API regardless of staleness. "
                    + "Useful for admin/manual refresh when the prime rate is known to have changed.")
    @ApiResponses({
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "200", description = "Prime rate refreshed successfully"),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "503", description = "External API unreachable",
                    content = @Content(schema = @Schema(implementation = ApiResponse.class)))
    })
    public ResponseEntity<ApiResponse<PrimeRateAdminView>> refresh() {
        log.info("POST /api/v1/prime/refresh");
        PrimeRateAdminView refreshed = service.refresh();
        return ApiResponse.ok(refreshed);
    }
}
