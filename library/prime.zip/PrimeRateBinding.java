package com.td.plra.service.primerate.binding;

import com.querydsl.core.types.dsl.BooleanExpression;
import com.td.plra.application.utils.BaseBinding;
import com.td.plra.persistence.entity.QPrimeRate;
import com.td.plra.persistence.enums.ActiveStatus;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * QueryDSL predicate builder for PrimeRate queries.
 * <p>
 * Builds dynamic WHERE clauses from request parameters. Supports:
 * <ul>
 *   <li>{@code source} — contains, case-insensitive</li>
 *   <li>{@code active} — Y/N filter (defaults to Y if not provided)</li>
 *   <li>{@code fetchedFrom/fetchedTo} — date range on FETCHED_ON</li>
 *   <li>{@code effectiveDateFrom/effectiveDateTo} — date range on EFFECTIVE_DATE</li>
 *   <li>{@code createdFrom/createdTo} — date range on CREATED_ON</li>
 * </ul>
 * </p>
 */
@Component
public class PrimeRateBinding extends BaseBinding {

    private static final QPrimeRate primeRate = QPrimeRate.primeRate;

    public BooleanExpression buildPredicate(Map<String, String> params) {
        BooleanExpression predicate = null;

        // Filter by source (contains, case-insensitive)
        if (hasParam(params, "source")) {
            predicate = and(predicate, primeRate.source.containsIgnoreCase(getParam(params, "source")));
        }

        // Filter by active status (defaults to Y if not provided)
        if (hasParam(params, "active")) {
            ActiveStatus status = ActiveStatus.valueOf(getParam(params, "active").toUpperCase());
            predicate = and(predicate, primeRate.active.eq(status));
        } else {
            predicate = and(predicate, primeRate.active.eq(ActiveStatus.Y));
        }

        // Filter by fetched date range
        predicate = and(predicate, dateRange(params, "fetchedFrom", "fetchedTo",
                (start, end) -> primeRate.fetchedOn.between(start, end)));

        // Filter by effective date range
        if (hasParam(params, "effectiveDateFrom") || hasParam(params, "effectiveDateTo")) {
            var from = parseDate(getParam(params, "effectiveDateFrom"));
            var to = parseDate(getParam(params, "effectiveDateTo"));
            if (from != null && to != null) {
                predicate = and(predicate, primeRate.effectiveDate.between(from, to));
            } else if (from != null) {
                predicate = and(predicate, primeRate.effectiveDate.goe(from));
            } else if (to != null) {
                predicate = and(predicate, primeRate.effectiveDate.loe(to));
            }
        }

        // Filter by created date range
        predicate = and(predicate, dateRange(params, "createdFrom", "createdTo",
                (start, end) -> primeRate.createdOn.between(start, end)));

        return predicate;
    }
}
