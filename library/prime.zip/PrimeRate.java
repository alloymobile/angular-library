package com.td.plra.persistence.entity;

import com.td.plra.application.utils.BaseAuditable;
import com.td.plra.persistence.enums.ActiveStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * JPA entity for the PRIME_RATE cache table.
 * <p>
 * DB2 Table: RATEMGMT.PRIME_RATE
 * Sequence: SEQ_PRIME_RATE_ID (CACHE 20)
 * </p>
 *
 * <b>Design:</b> This is a cache table for prime rates fetched on-demand from
 * an external API. No manual entry — data is populated by the service layer
 * when the UI requests the current prime rate and the cached value is stale
 * (older than 24 hours) or missing.
 *
 * <b>Note:</b> Prime rate is universal — it applies to ALL products (ULOC, ILOC).
 * There is no Product FK. One prime rate at a time for the entire system.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "PRIME_RATE")
@EntityListeners(AuditingEntityListener.class)
public class PrimeRate extends BaseAuditable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @Column(name = "RATE_VALUE", nullable = false, precision = 10, scale = 6)
    private BigDecimal rateValue;

    @Column(name = "EFFECTIVE_DATE", nullable = false)
    private LocalDate effectiveDate;

    @Column(name = "SOURCE", length = 200)
    private String source;

    @Column(name = "DETAIL", length = 2000)
    private String detail;

    @Enumerated(EnumType.STRING)
    @Column(name = "ACTIVE", nullable = false, length = 1)
    private ActiveStatus active;

    @Column(name = "FETCHED_ON", nullable = false)
    private LocalDateTime fetchedOn;
}
