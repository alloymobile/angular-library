    // ================================================================
    // PRIME RATE
    // Add this block to TestDataFactory.java
    // Also add these imports:
    //   import com.td.plra.persistence.entity.PrimeRate;
    //   import com.td.plra.service.primerate.dto.PrimeRateAdminView;
    //   import com.td.plra.service.primerate.dto.PrimeRateUserView;
    // ================================================================
    public static PrimeRate primeRate() { return primeRate(500L); }
    public static PrimeRate primeRate(Long id) {
        PrimeRate pr = new PrimeRate(); pr.setId(id);
        pr.setRateValue(new BigDecimal("7.200000")); pr.setEffectiveDate(LocalDate.of(2026, 4, 1));
        pr.setSource("Bank of Canada"); pr.setDetail("Current prime rate");
        pr.setActive(ActiveStatus.Y); pr.setFetchedOn(LocalDateTime.now());
        pr.setCreatedBy("SYSTEM"); pr.setCreatedOn(LocalDateTime.now()); pr.setVersion(1); return pr;
    }
    public static PrimeRateAdminView primeRateAdminView() { return primeRateAdminView(500L); }
    public static PrimeRateAdminView primeRateAdminView(Long id) {
        return PrimeRateAdminView.builder().id(id)
                .rateValue(new BigDecimal("7.200000")).effectiveDate(LocalDate.of(2026, 4, 1))
                .source("Bank of Canada").detail("Current prime rate").active(true)
                .fetchedOn(LocalDateTime.now()).createdBy("SYSTEM").createdOn(LocalDateTime.now())
                .version(1).build();
    }
    public static PrimeRateUserView primeRateUserView() {
        return PrimeRateUserView.builder().id(500L).rateValue(new BigDecimal("7.200000"))
                .effectiveDate(LocalDate.of(2026, 4, 1)).source("Bank of Canada")
                .detail("Current prime rate").fetchedOn(LocalDateTime.now()).build();
    }
