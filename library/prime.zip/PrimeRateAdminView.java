package com.td.plra.service.primerate.dto;

import com.td.plra.service.product.dto.ProductUserView;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Admin view DTO for PrimeRate.
 * <p>
 * Exposes all fields including audit columns, version, and the product
 * reference as a lightweight {@link ProductUserView}. The {@code active}
 * field is a boolean (mapped from {@code ActiveStatus} enum by the mapper).
 * </p>
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PrimeRateAdminView {

    private Long id;
    private ProductUserView product;
    private BigDecimal rateValue;
    private LocalDate effectiveDate;
    private String source;
    private String detail;
    private boolean active;
    private LocalDateTime fetchedOn;
    private String createdBy;
    private LocalDateTime createdOn;
    private String updatedBy;
    private LocalDateTime updatedOn;
    private Integer version;
}
