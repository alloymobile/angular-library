package com.td.plra.service.primerate.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Admin view DTO for PrimeRate.
 * <p>
 * Exposes all fields including audit columns and version.
 * Prime rate is universal — applies to all products, so there
 * is no product reference.
 * </p>
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PrimeRateAdminView {

    private Long id;
    private BigDecimal rateValue;
    private LocalDate effectiveDate;
    private String source;
    private String detail;
    private boolean active;
    private LocalDateTime fetchedOn;
    private String createdBy;
    private LocalDateTime createdOn;
    private String updatedBy;
    private LocalDateTime updatedOn;
    private Integer version;
}
