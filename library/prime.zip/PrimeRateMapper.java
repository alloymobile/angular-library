package com.td.plra.service.primerate.mapper;

import com.td.plra.persistence.entity.PrimeRate;
import com.td.plra.persistence.enums.ActiveStatus;
import com.td.plra.service.primerate.dto.PrimeRateAdminView;
import com.td.plra.service.primerate.dto.PrimeRateUserView;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;

import java.util.List;

/**
 * MapStruct mapper for PrimeRate entity ↔ DTO conversions.
 * <p>
 * Configuration:
 * <ul>
 *   <li>Unmapped targets are ignored (forward compatibility)</li>
 *   <li>ActiveStatus enum maps to boolean for view DTOs</li>
 *   <li>No Input → Entity mapping since prime rates are not manually created</li>
 * </ul>
 * </p>
 */
@Mapper(componentModel = "spring",
        unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface PrimeRateMapper {

    // ====== ENTITY → ADMIN VIEW ======

    @Mapping(target = "active", source = "active", qualifiedByName = "activeStatusToBoolean")
    PrimeRateAdminView toAdminView(PrimeRate entity);

    List<PrimeRateAdminView> toAdminViewList(List<PrimeRate> entities);

    // ====== ENTITY → USER VIEW ======

    PrimeRateUserView toUserView(PrimeRate entity);

    List<PrimeRateUserView> toUserViewList(List<PrimeRate> entities);

    // ====== NAMED CONVERTERS ======

    @Named("activeStatusToBoolean")
    default boolean activeStatusToBoolean(ActiveStatus status) {
        return status == ActiveStatus.Y;
    }
}
