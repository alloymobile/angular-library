package com.td.plra.service.primerate;

import com.td.plra.application.exception.EntityNotFoundException;
import com.td.plra.application.utils.PageResponse;
import com.td.plra.persistence.entity.PrimeRate;
import com.td.plra.persistence.entity.Product;
import com.td.plra.persistence.enums.ActiveStatus;
import com.td.plra.persistence.repository.PrimeRateRepository;
import com.td.plra.service.primerate.binding.PrimeRateBinding;
import com.td.plra.service.primerate.client.ExternalPrimeRateClient;
import com.td.plra.service.primerate.client.ExternalPrimeRateClient.PrimeRateResponse;
import com.td.plra.service.primerate.dto.PrimeRateAdminView;
import com.td.plra.service.primerate.mapper.PrimeRateMapper;
import com.td.plra.service.product.ProductService;
import com.td.plra.testutil.TestDataFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PrimeRateServiceTest {

    @Mock private PrimeRateRepository repository;
    @Mock private PrimeRateMapper mapper;
    @Mock private PrimeRateBinding binding;
    @Mock private ExternalPrimeRateClient externalClient;
    @Mock private ProductService productService;

    @InjectMocks private PrimeRateService service;

    private Product product;
    private PrimeRate entity;
    private PrimeRateAdminView adminView;
    private Pageable pageable;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(service, "stalenessHours", 24);
        product = TestDataFactory.product();
        entity = TestDataFactory.primeRate();
        adminView = TestDataFactory.primeRateAdminView();
        pageable = PageRequest.of(0, 20);
    }

    @Nested @DisplayName("getCurrent")
    class GetCurrentTests {

        @Test @DisplayName("Should return cached value when fresh")
        void returnsCachedWhenFresh() {
            entity.setFetchedOn(LocalDateTime.now().minusHours(1)); // 1 hour ago = fresh

            when(productService.getEntityById(1L)).thenReturn(product);
            when(repository.findFirstByProductIdAndActiveOrderByFetchedOnDesc(1L, ActiveStatus.Y))
                    .thenReturn(Optional.of(entity));
            when(mapper.toAdminView(entity)).thenReturn(adminView);

            PrimeRateAdminView result = service.getCurrent(1L);

            assertThat(result).isEqualTo(adminView);
            verify(externalClient, never()).fetchPrimeRate();
        }

        @Test @DisplayName("Should fetch from external API when stale")
        void fetchesFromApiWhenStale() {
            entity.setFetchedOn(LocalDateTime.now().minusHours(25)); // 25 hours ago = stale

            PrimeRateResponse apiResponse = new PrimeRateResponse();
            apiResponse.setRate(new BigDecimal("7.200000"));
            apiResponse.setEffectiveDate(LocalDate.now());
            apiResponse.setSource("Bank of Canada");
            apiResponse.setDescription("Current prime rate");

            when(productService.getEntityById(1L)).thenReturn(product);
            when(repository.findFirstByProductIdAndActiveOrderByFetchedOnDesc(1L, ActiveStatus.Y))
                    .thenReturn(Optional.of(entity));
            when(repository.findByProductIdAndActive(1L, ActiveStatus.Y))
                    .thenReturn(List.of(entity));
            when(externalClient.fetchPrimeRate()).thenReturn(apiResponse);
            when(repository.save(any(PrimeRate.class))).thenAnswer(inv -> inv.getArgument(0));
            when(mapper.toAdminView(any(PrimeRate.class))).thenReturn(adminView);

            PrimeRateAdminView result = service.getCurrent(1L);

            assertThat(result).isEqualTo(adminView);
            verify(externalClient).fetchPrimeRate();
        }

        @Test @DisplayName("Should fetch from external API when no cached value")
        void fetchesFromApiWhenMissing() {
            PrimeRateResponse apiResponse = new PrimeRateResponse();
            apiResponse.setRate(new BigDecimal("7.200000"));
            apiResponse.setEffectiveDate(LocalDate.now());
            apiResponse.setSource("Bank of Canada");
            apiResponse.setDescription("Current prime rate");

            when(productService.getEntityById(1L)).thenReturn(product);
            when(repository.findFirstByProductIdAndActiveOrderByFetchedOnDesc(1L, ActiveStatus.Y))
                    .thenReturn(Optional.empty());
            when(repository.findByProductIdAndActive(1L, ActiveStatus.Y))
                    .thenReturn(List.of());
            when(externalClient.fetchPrimeRate()).thenReturn(apiResponse);
            when(repository.save(any(PrimeRate.class))).thenAnswer(inv -> inv.getArgument(0));
            when(mapper.toAdminView(any(PrimeRate.class))).thenReturn(adminView);

            PrimeRateAdminView result = service.getCurrent(1L);

            assertThat(result).isEqualTo(adminView);
            verify(externalClient).fetchPrimeRate();
        }

        @Test @DisplayName("Should return stale fallback when external API fails")
        void returnsStaleFallbackOnApiFailure() {
            entity.setFetchedOn(LocalDateTime.now().minusHours(25));

            when(productService.getEntityById(1L)).thenReturn(product);
            when(repository.findFirstByProductIdAndActiveOrderByFetchedOnDesc(1L, ActiveStatus.Y))
                    .thenReturn(Optional.of(entity));
            when(repository.findByProductIdAndActive(1L, ActiveStatus.Y))
                    .thenReturn(List.of(entity));
            when(externalClient.fetchPrimeRate()).thenThrow(new RuntimeException("API down"));
            when(mapper.toAdminView(entity)).thenReturn(adminView);

            PrimeRateAdminView result = service.getCurrent(1L);

            assertThat(result).isEqualTo(adminView);
        }

        @Test @DisplayName("Should throw when external API fails and no cached value")
        void throwsWhenApiFailsAndNoCached() {
            when(productService.getEntityById(1L)).thenReturn(product);
            when(repository.findFirstByProductIdAndActiveOrderByFetchedOnDesc(1L, ActiveStatus.Y))
                    .thenReturn(Optional.empty());
            when(repository.findByProductIdAndActive(1L, ActiveStatus.Y))
                    .thenReturn(List.of());
            when(externalClient.fetchPrimeRate()).thenThrow(new RuntimeException("API down"));

            assertThatThrownBy(() -> service.getCurrent(1L))
                    .isInstanceOf(RuntimeException.class)
                    .hasMessageContaining("external API is unreachable");
        }
    }

    @Nested @DisplayName("findById")
    class FindByIdTests {
        @Test @DisplayName("Should return admin view when found")
        void returnsAdminViewWhenFound() {
            when(repository.findById(500L)).thenReturn(Optional.of(entity));
            when(mapper.toAdminView(entity)).thenReturn(adminView);

            PrimeRateAdminView result = service.findById(500L);

            assertThat(result).isEqualTo(adminView);
        }

        @Test @DisplayName("Should throw EntityNotFoundException when not found")
        void throwsWhenNotFound() {
            when(repository.findById(999L)).thenReturn(Optional.empty());

            assertThatThrownBy(() -> service.findById(999L))
                    .isInstanceOf(EntityNotFoundException.class);
        }
    }

    @Nested @DisplayName("findAll")
    class FindAllTests {
        @Test @DisplayName("Should return paginated results")
        void returnsPaginatedResults() {
            Page<PrimeRate> page = new PageImpl<>(List.of(entity), pageable, 1);
            when(binding.buildPredicate(any())).thenReturn(null);
            when(repository.findAll(pageable)).thenReturn(page);
            when(mapper.toAdminViewList(List.of(entity))).thenReturn(List.of(adminView));

            Map<String, String> params = new HashMap<>();
            PageResponse<PrimeRateAdminView> result = service.findAll(params, pageable);

            assertThat(result.getContent()).hasSize(1);
            assertThat(result.getTotalElements()).isEqualTo(1);
        }
    }

    @Nested @DisplayName("refresh")
    class RefreshTests {
        @Test @DisplayName("Should force fetch from external API")
        void forcesFetch() {
            PrimeRateResponse apiResponse = new PrimeRateResponse();
            apiResponse.setRate(new BigDecimal("7.200000"));
            apiResponse.setEffectiveDate(LocalDate.now());
            apiResponse.setSource("Bank of Canada");
            apiResponse.setDescription("Current prime rate");

            when(productService.getEntityById(1L)).thenReturn(product);
            when(repository.findFirstByProductIdAndActiveOrderByFetchedOnDesc(1L, ActiveStatus.Y))
                    .thenReturn(Optional.empty());
            when(repository.findByProductIdAndActive(1L, ActiveStatus.Y))
                    .thenReturn(List.of());
            when(externalClient.fetchPrimeRate()).thenReturn(apiResponse);
            when(repository.save(any(PrimeRate.class))).thenAnswer(inv -> inv.getArgument(0));
            when(mapper.toAdminView(any(PrimeRate.class))).thenReturn(adminView);

            PrimeRateAdminView result = service.refresh(1L);

            assertThat(result).isEqualTo(adminView);
            verify(externalClient).fetchPrimeRate();
        }
    }
}
