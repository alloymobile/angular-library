-- ============================================================================
-- PLRA - Database Migration Script
-- Script: 10_prime_rate_table.sql
-- Purpose: PRIME_RATE table as a cache for external prime rates
-- Author: Database Administrator
-- Created: 2026-04-07
-- Version: 3.0
-- ============================================================================
--
-- DESIGN NOTES:
-- =============
-- 1. This is a CACHE table — data is fetched from an external API on-demand
-- 2. No Draft/Active/History lifecycle — prime rates are read-only
-- 3. 24-hour staleness rule: if FETCHED_ON > 24 hours ago, re-fetch from API
-- 4. No maker-checker workflow applies to this table
-- 5. Prime rate is UNIVERSAL — applies to ALL products (no Product FK)
-- 6. Only one ACTIVE record at a time; previous records are deactivated
--
-- ============================================================================

SET CURRENT SCHEMA = 'RATEMGMT';

-- ============================================================================
-- SEQUENCE: SEQ_PRIME_RATE_ID
-- ============================================================================
CREATE SEQUENCE SEQ_PRIME_RATE_ID
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO CYCLE
    CACHE 20;

-- ============================================================================
-- TABLE: PRIME_RATE
-- Purpose: Cached prime rate values fetched from external API
-- Columns: 11
-- PK: ID (auto-generated via IDENTITY)
-- No FK — prime rate is universal, not linked to any product
-- ============================================================================
CREATE TABLE PRIME_RATE (
    ID                  BIGINT          NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
    RATE_VALUE          DECIMAL(10,6)   NOT NULL,
    EFFECTIVE_DATE      DATE            NOT NULL,
    SOURCE              VARCHAR(200)    NULL,
    DETAIL              VARCHAR(2000)   NULL,
    ACTIVE              CHAR(1)         NOT NULL DEFAULT 'Y',
    FETCHED_ON          TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CREATED_BY          VARCHAR(100)    NOT NULL DEFAULT 'SYSTEM',
    CREATED_ON          TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UPDATED_BY          VARCHAR(100)    NULL,
    UPDATED_ON          TIMESTAMP       NULL,
    VERSION             INTEGER         NOT NULL DEFAULT 1,

    CONSTRAINT PK_PRIME_RATE PRIMARY KEY (ID),
    CONSTRAINT CHK_PRIME_ACTIVE CHECK (ACTIVE IN ('Y', 'N')),
    CONSTRAINT CHK_PRIME_RATE_VALUE CHECK (RATE_VALUE >= 0)
);

COMMENT ON TABLE PRIME_RATE IS 'Cached prime rate values fetched on-demand from external API — universal for all products';
COMMENT ON COLUMN PRIME_RATE.ID IS 'Primary key - auto generated';
COMMENT ON COLUMN PRIME_RATE.RATE_VALUE IS 'Prime interest rate value (6 decimal precision)';
COMMENT ON COLUMN PRIME_RATE.EFFECTIVE_DATE IS 'Date the prime rate became effective';
COMMENT ON COLUMN PRIME_RATE.SOURCE IS 'Source identifier of the external API';
COMMENT ON COLUMN PRIME_RATE.FETCHED_ON IS 'Timestamp when this rate was fetched — used for 24hr staleness check';
COMMENT ON COLUMN PRIME_RATE.ACTIVE IS 'Active flag: Y=Active, N=Inactive';
COMMENT ON COLUMN PRIME_RATE.VERSION IS 'Optimistic locking version number';

-- ============================================================================
-- INDEXES
-- ============================================================================
CREATE INDEX IDX_PRIME_ACTIVE ON PRIME_RATE (ACTIVE);
CREATE INDEX IDX_PRIME_FETCHED ON PRIME_RATE (FETCHED_ON DESC);
CREATE INDEX IDX_PRIME_EFFDATE ON PRIME_RATE (EFFECTIVE_DATE DESC);
CREATE INDEX IDX_PRIME_ACTIVE_FETCHED ON PRIME_RATE (ACTIVE, FETCHED_ON DESC);

-- ============================================================================
-- END OF SCRIPT
-- ============================================================================
