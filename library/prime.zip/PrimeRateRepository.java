package com.td.plra.persistence.repository;

import com.td.plra.persistence.entity.PrimeRate;
import com.td.plra.persistence.enums.ActiveStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Spring Data JPA repository for PRIME_RATE.
 * <p>
 * Extends {@link QuerydslPredicateExecutor} for dynamic filtering via QueryDSL
 * predicates built by {@link com.td.plra.service.primerate.binding.PrimeRateBinding}.
 * </p>
 */
@Repository
public interface PrimeRateRepository extends JpaRepository<PrimeRate, Long>, QuerydslPredicateExecutor<PrimeRate> {

    /**
     * Find the most recent active prime rate for a product.
     * Used for: staleness check before calling external API.
     */
    Optional<PrimeRate> findFirstByProductIdAndActiveOrderByFetchedOnDesc(Long productId, ActiveStatus active);

    /**
     * Find all prime rates by product and active status.
     * Used for: deactivating previous records when a new rate is fetched.
     */
    List<PrimeRate> findByProductIdAndActive(Long productId, ActiveStatus active);
}
