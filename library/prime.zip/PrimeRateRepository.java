package com.td.plra.persistence.repository;

import com.td.plra.persistence.entity.PrimeRate;
import com.td.plra.persistence.enums.ActiveStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Spring Data JPA repository for PRIME_RATE.
 * <p>
 * Extends {@link QuerydslPredicateExecutor} for dynamic filtering via QueryDSL
 * predicates built by {@link com.td.plra.service.primerate.binding.PrimeRateBinding}.
 * </p>
 *
 * <b>Note:</b> Prime rate is universal — no Product FK. One active rate at a time.
 */
@Repository
public interface PrimeRateRepository extends JpaRepository<PrimeRate, Long>, QuerydslPredicateExecutor<PrimeRate> {

    /**
     * Find the most recent active prime rate.
     * Used for: staleness check before calling external API.
     */
    Optional<PrimeRate> findFirstByActiveOrderByFetchedOnDesc(ActiveStatus active);

    /**
     * Find all active prime rates.
     * Used for: deactivating previous records when a new rate is fetched.
     */
    List<PrimeRate> findByActive(ActiveStatus active);
}
