package com.td.plra.service.primerate.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Lightweight user-facing view DTO for PrimeRate.
 * <p>
 * Used for displaying prime rate on the UI without admin audit details.
 * Contains the rate value, effective date, source, and when it was last
 * fetched from the external API.
 * </p>
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PrimeRateUserView {

    private Long id;
    private BigDecimal rateValue;
    private LocalDate effectiveDate;
    private String source;
    private String detail;
    private LocalDateTime fetchedOn;
}
