-- ============================================================================
-- H2 Compatible - Prime Rate Table (for local dev / unit tests)
-- Add to your existing schema.sql or data.sql
-- ============================================================================

CREATE TABLE IF NOT EXISTS PRIME_RATE (
    ID                  BIGINT          AUTO_INCREMENT PRIMARY KEY,
    PRODUCT_ID          BIGINT          NOT NULL,
    RATE_VALUE          DECIMAL(10,6)   NOT NULL,
    EFFECTIVE_DATE      DATE            NOT NULL,
    SOURCE              VARCHAR(200)    NULL,
    DETAIL              VARCHAR(2000)   NULL,
    ACTIVE              CHAR(1)         NOT NULL DEFAULT 'Y',
    FETCHED_ON          TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CREATED_BY          VARCHAR(100)    NOT NULL DEFAULT 'SYSTEM',
    CREATED_ON          TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UPDATED_BY          VARCHAR(100)    NULL,
    UPDATED_ON          TIMESTAMP       NULL,
    VERSION             INTEGER         NOT NULL DEFAULT 1,
    CONSTRAINT FK_PRIME_PRODUCT FOREIGN KEY (PRODUCT_ID) REFERENCES PRODUCT (ID)
);
