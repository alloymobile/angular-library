package com.td.plra.resource;

import com.td.plra.application.utils.ApiResponse;
import com.td.plra.application.utils.PageResponse;
import com.td.plra.service.primerate.PrimeRateService;
import com.td.plra.service.primerate.dto.PrimeRateAdminView;
import com.td.plra.testutil.TestDataFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PrimeRateResourceTest {

    @Mock private PrimeRateService service;
    @InjectMocks private PrimeRateResource resource;

    private PrimeRateAdminView adminView;
    private Pageable pageable;

    @BeforeEach
    void setUp() {
        adminView = TestDataFactory.primeRateAdminView();
        pageable = PageRequest.of(0, 20);
    }

    @Nested @DisplayName("GET /api/v1/prime/current")
    class GetCurrentTests {
        @Test @DisplayName("Should return 200 OK with current prime rate")
        void getCurrentReturns200() {
            when(service.getCurrent()).thenReturn(adminView);

            ResponseEntity<ApiResponse<PrimeRateAdminView>> response = resource.getCurrent();

            assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
            assertThat(response.getBody()).isNotNull();
            assertThat(response.getBody().isSuccess()).isTrue();
            assertThat(response.getBody().getData().getRateValue()).isEqualTo(adminView.getRateValue());
            verify(service).getCurrent();
        }
    }

    @Nested @DisplayName("GET /api/v1/prime/{id}")
    class FindByIdTests {
        @Test @DisplayName("Should return 200 OK")
        void findByIdReturns200() {
            when(service.findById(500L)).thenReturn(adminView);

            ResponseEntity<ApiResponse<PrimeRateAdminView>> response = resource.findById(500L);

            assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
            assertThat(response.getBody().getData().getId()).isEqualTo(500L);
        }
    }

    @Nested @DisplayName("GET /api/v1/prime")
    class FindAllTests {
        @Test @DisplayName("Should return 200 OK with page")
        void findAllReturns200() {
            PageResponse<PrimeRateAdminView> page = PageResponse.<PrimeRateAdminView>builder()
                    .content(List.of(adminView)).page(0).size(20)
                    .totalElements(1).totalPages(1).first(true).last(true).empty(false).build();
            Map<String, String> params = new HashMap<>();
            when(service.findAll(any(), any(Pageable.class))).thenReturn(page);

            ResponseEntity<ApiResponse<PageResponse<PrimeRateAdminView>>> response =
                    resource.findAll(null, null, null, null, null, null, null, null,
                            false, params, pageable);

            assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
            assertThat(response.getBody().getData().getContent()).hasSize(1);
        }
    }

    @Nested @DisplayName("POST /api/v1/prime/refresh")
    class RefreshTests {
        @Test @DisplayName("Should return 200 OK with refreshed prime rate")
        void refreshReturns200() {
            when(service.refresh()).thenReturn(adminView);

            ResponseEntity<ApiResponse<PrimeRateAdminView>> response = resource.refresh();

            assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
            assertThat(response.getBody().isSuccess()).isTrue();
            verify(service).refresh();
        }
    }
}
