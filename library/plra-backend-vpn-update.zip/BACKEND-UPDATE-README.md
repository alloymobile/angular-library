# PLRA v2.0 — Backend Update for VPN

## Overview

This package contains **7 Java files** to replace on the VPN backend. These changes add:

1. **REVIEW workflow action** — audit trail for reviewers (rate stays ACTIVE)
2. **Review endpoints** — `PATCH /active/{id}/review` for ULOC and ILOC
3. **ChangeId fix** — generates new changeId on every workflow transition (fixes UK constraint violation)
4. **Comma-separated filter support** — `subCategoryIds` and `cvpCodeIds` query parameters
5. **H2 + DB2 compatible queries** — uses OR-based equals instead of `.in()` for cross-database compatibility

---

## Files and Destinations

| # | File | Destination Path | What Changed |
|---|------|-----------------|--------------|
| 1 | `WorkflowAction.java` | `src/main/java/com/td/plra/persistence/enums/` | Added `REVIEW("Rate reviewed for audit")` |
| 2 | `RateIlocResource.java` | `src/main/java/com/td/plra/resource/` | Added `PATCH /api/v1/rates/iloc/active/{id}/review?message=` |
| 3 | `RateUlocResource.java` | `src/main/java/com/td/plra/resource/` | Added `PATCH /api/v1/rates/uloc/active/{id}/review?message=` |
| 4 | `RateIlocService.java` | `src/main/java/com/td/plra/service/rateiloc/` | Added `reviewRate()` + changeId fix on all transitions |
| 5 | `RateUlocService.java` | `src/main/java/com/td/plra/service/rateuloc/` | Added `reviewRate()` + changeId fix on all transitions |
| 6 | `RateUlocBinding.java` | `src/main/java/com/td/plra/service/rateuloc/binding/` | Added `subCategoryIds` + `cvpCodeIds` comma-separated filter |
| 7 | `RateIlocBinding.java` | `src/main/java/com/td/plra/service/rateiloc/binding/` | Added `subCategoryIds` comma-separated filter |

---

## Copy Commands

```bash
cd ~/alloymobile/plra/plra-api

cp WorkflowAction.java      src/main/java/com/td/plra/persistence/enums/
cp RateIlocResource.java     src/main/java/com/td/plra/resource/
cp RateUlocResource.java     src/main/java/com/td/plra/resource/
cp RateIlocService.java      src/main/java/com/td/plra/service/rateiloc/
cp RateUlocService.java      src/main/java/com/td/plra/service/rateuloc/
cp RateUlocBinding.java      src/main/java/com/td/plra/service/rateuloc/binding/
cp RateIlocBinding.java      src/main/java/com/td/plra/service/rateiloc/binding/
```

---

## New API Endpoints

### Review (Audit Only — Rate stays ACTIVE)

```
PATCH /api/v1/rates/uloc/active/{id}/review?message=Reviewed
PATCH /api/v1/rates/iloc/active/{id}/review?message=Reviewed
```

**Response:** `204 No Content`
**What it does:** Creates a workflow entry `(REVIEW, ACTIVE → ACTIVE)`. Rate status does NOT change. Purely for audit trail.

---

## New Query Parameters

### ULOC Active/Draft/History

| Parameter | Type | Example | Description |
|-----------|------|---------|-------------|
| `subCategoryIds` | comma-separated | `?subCategoryIds=1,2,5` | Filter by multiple subcategory IDs |
| `cvpCodeIds` | comma-separated | `?cvpCodeIds=3,7,12` | Filter by multiple CVP code IDs |

### ILOC Active/Draft/History

| Parameter | Type | Example | Description |
|-----------|------|---------|-------------|
| `subCategoryIds` | comma-separated | `?subCategoryIds=2,4` | Filter by multiple subcategory IDs |

### Backward Compatibility

Existing single-value parameters still work:

```
?subCategoryId=1      (single — still works)
?subCategoryIds=1,2   (multi — new)
?cvpCodeId=3          (single — still works)
?cvpCodeIds=3,7       (multi — new)
```

If both `subCategoryId` and `subCategoryIds` are sent, `subCategoryIds` takes priority.

---

## ChangeId Fix Details

**Problem:** Workflow table unique constraint `UK_WORKFLOW(RATE_TYPE, RATE_ID, CHANGE_ID)` was violated because all state transitions reused the same changeId from `createDraft`.

**Fix:** Added `entity.setChangeId(workflowService.generateChangeId())` before every `workflowService.recordTransition()` call.

**Methods fixed in both `RateIlocService.java` and `RateUlocService.java`:**
- `updateDraft` — new changeId
- `deleteDraft` — new changeId
- `submitForApproval` — new changeId
- `approve` — separate archiveChangeId + approveChangeId
- `reject` — new changeId
- `expireRate` — new changeId
- `reviewRate` — new changeId (new method)

Total: 9 `generateChangeId()` calls per service file.

---

## Database Compatibility

The comma-separated filter uses **OR-based equals** instead of `.in()`:

```sql
-- Generated SQL (works on H2, DB2, SQL Server, Azure SQL)
WHERE (cc1_0.SUB_CATEGORY_ID = ? OR cc1_0.SUB_CATEGORY_ID = ?)
  AND rua1_0.ACTIVE = ?
```

This is standard SQL compatible with all target databases.

---

## Verification After Deployment

```bash
# 1. Check review endpoint
curl -X PATCH "http://localhost:8080/plra/api/v1/rates/uloc/active/1/review?message=Test"
# Expected: 204 No Content

# 2. Check comma-separated filter
curl "http://localhost:8080/plra/api/v1/rates/uloc/active?size=20&subCategoryIds=1,2"
# Expected: filtered results

# 3. Check single filter still works
curl "http://localhost:8080/plra/api/v1/rates/uloc/active?size=20&subCategoryId=1"
# Expected: same as before
```
