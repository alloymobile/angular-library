import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TranslationService } from '../../../core/i18n/translation.service';
import { RateApiService } from '../../../core/services/rate-api.service';
import { AmountTierAdminView } from '../../../core/models/api.models';
import { RateMatrixComponent, MatrixTier, MatrixRow } from '../../../shared/components/rate-matrix/rate-matrix';
import { RateFilterComponent, FilterState } from '../../../shared/components/rate-filter/rate-filter';
import { buildViewMatrix } from '../../../shared/components/matrix-data-builder';

type Tab = 'view' | 'review';

@Component({
  selector: 'plra-reviewer-iloc',
  standalone: true,
  imports: [CommonModule, FormsModule, RateMatrixComponent, RateFilterComponent],
  templateUrl: './reviewer-iloc.html',
  styleUrls: ['./reviewer-iloc.css']
})
export class ReviewerIlocComponent implements OnInit {
  t = inject(TranslationService);
  private api = inject(RateApiService);

  tab = signal<Tab>('view');
  tiers = signal<MatrixTier[]>([]);
  viewRows = signal<MatrixRow[]>([]);
  filteredViewRows = signal<MatrixRow[]>([]);
  reviewRows = signal<MatrixRow[]>([]);
  filteredReviewRows = signal<MatrixRow[]>([]);
  reviewSearch = '';
  viewSearch = '';
  visibleTierIds: number[] = [];
  allSelected = false;
  reviewing = signal(false);
  message = signal('');
  messageType = signal<'success' | 'error' | 'info'>('info');
  productName = '';

  private tierData: AmountTierAdminView[] = [];

  ngOnInit(): void {
    this.api.getProducts({ type: 'ILOC', size: 1 }).subscribe({
      next: (res: any) => {
        const p = res.content.find((x: any) => x.type === 'ILOC');
        if (!p) return;
        this.productName = p.name;
        this.api.getAmountTiers(p.name, { unpaged: true }).subscribe({
          next: (tierRes: any) => {
            this.tierData = tierRes.content;
            this.tiers.set(tierRes.content.map((t: any) => ({ id: t.id, name: t.name })));
            this.loadActive();
          }
        });
      }
    });
  }

  switchTab(tab: Tab): void {
    this.tab.set(tab);
    this.message.set('');
    this.loadActive();
  }

  private loadActive(): void {
    this.api.getIlocActive({ size: 500 }).subscribe({
      next: (r: any) => {
        const m = buildViewMatrix(this.tierData, r.content, 'ILOC');
        this.viewRows.set(m.matrixRows);
        this.filteredViewRows.set(m.matrixRows);
        this.reviewRows.set(m.matrixRows.map((row: any) => ({ ...row, selected: false })));
        this.applyReviewFilter();
      }
    });
  }

  applyReviewFilter(): void {
    if (!this.reviewSearch) { this.filteredReviewRows.set(this.reviewRows()); return; }
    const term = this.reviewSearch.toLowerCase();
    this.filteredReviewRows.set(this.reviewRows().filter((r: any) => r.name.toLowerCase().includes(term)));
  }

  toggleAll(e: Event): void {
    const checked = (e.target as HTMLInputElement).checked;
    this.filteredReviewRows().forEach((r: any) => r.selected = checked);
    this.allSelected = checked;
  }

  submitReview(): void {
    const selected = this.reviewRows().filter((r: any) => r.selected);
    if (selected.length === 0) { this.showMsg(this.t.get('rates.select_rows') as string, 'info'); return; }

    const activeIds: number[] = [];
    for (const row of selected) {
      for (const cell of row.cells) {
        if (cell.activeId !== null && cell.activeId !== undefined && cell.activeId > 0) {
          activeIds.push(cell.activeId);
        }
      }
    }
    if (activeIds.length === 0) { this.showMsg('No active rates found for selected rows.', 'info'); return; }

    this.reviewing.set(true);
    let done = 0, errors = 0;
    for (const id of activeIds) {
      this.api.reviewIlocActive(id, 'Reviewed').subscribe({
        next: () => { done++; if (done + errors >= activeIds.length) this.onComplete(done, errors, selected.length); },
        error: () => { errors++; if (done + errors >= activeIds.length) this.onComplete(done, errors, selected.length); }
      });
    }
  }

  private onComplete(done: number, errors: number, rowCount: number): void {
    this.reviewing.set(false);
    this.reviewRows().forEach((r: any) => r.selected = false);
    this.allSelected = false;
    this.showMsg(`Reviewed ${rowCount} row(s) (${done} rate(s)).${errors > 0 ? ` ${errors} failed.` : ''}`, errors > 0 ? 'error' : 'success');
  }

  onViewFilter(f: FilterState): void {
    this.viewSearch = f.search;
    this.visibleTierIds = f.tierIds.map((id: string) => Number(id));
    const params: Record<string, any> = {};
    if (f.subCategoryIds.length > 0) params['subCategoryIds'] = f.subCategoryIds.join(',');
    this.api.getIlocActive({ size: 500, ...params }).subscribe({
      next: (r: any) => {
        const m = buildViewMatrix(this.tierData, r.content, 'ILOC');
        this.viewRows.set(m.matrixRows);
        this.filteredViewRows.set(m.matrixRows);
      }
    });
  }

  private showMsg(msg: string, type: 'success' | 'error' | 'info'): void { this.message.set(msg); this.messageType.set(type); }
}
