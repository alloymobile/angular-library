import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslationService } from '../../../core/i18n/translation.service';
import { RateApiService } from '../../../core/services/rate-api.service';
import { AmountTierAdminView } from '../../../core/models/api.models';
import { RateMatrixComponent, MatrixTier, MatrixRow } from '../../../shared/components/rate-matrix/rate-matrix';
import { RateFilterComponent, FilterState } from '../../../shared/components/rate-filter/rate-filter';
import { buildViewMatrix } from '../../../shared/components/matrix-data-builder';

@Component({
  selector: 'plra-viewer-uloc', standalone: true,
  imports: [CommonModule, RateMatrixComponent, RateFilterComponent],
  templateUrl: './viewer-uloc.html', styleUrls: ['./viewer-uloc.css']
})
export class ViewerUlocComponent implements OnInit {
  t = inject(TranslationService);
  private api = inject(RateApiService);
  tiers = signal<MatrixTier[]>([]);
  rows = signal<MatrixRow[]>([]);
  productName = '';
  searchTerm = '';
  visibleTierIds: number[] = [];
  private tierData: AmountTierAdminView[] = [];

  ngOnInit(): void {
    this.api.getProducts({ type: 'ULOC', size: 1 }).subscribe({ next: (res: any) => {
      const p = res.content.find((x: any) => x.type === 'ULOC');
      if (!p) return;
      this.productName = p.name;
      this.api.getAmountTiers(p.name, { unpaged: true }).subscribe({ next: (tierRes: any) => {
        this.tierData = tierRes.content;
        this.tiers.set(tierRes.content.map((t: any) => ({ id: t.id, name: t.name })));
        this.loadActive({});
      }});
    }});
  }

  private loadActive(params: Record<string, any>): void {
    this.api.getUlocActive({ size: 500, ...params }).subscribe({ next: (r: any) => {
      this.rows.set(buildViewMatrix(this.tierData, r.content, 'ULOC').matrixRows);
    }});
  }

  onFilter(f: FilterState): void {
    this.searchTerm = f.search;
    this.visibleTierIds = f.tierIds.map((id: string) => Number(id));
    const params: Record<string, any> = {};
    if (f.subCategoryIds.length > 0) params['subCategoryIds'] = f.subCategoryIds.join(',');
    this.loadActive(params);
  }
}
