import { Component, inject, signal, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { forkJoin } from 'rxjs';
import { TranslationService } from '../../../core/i18n/translation.service';
import { RateApiService } from '../../../core/services/rate-api.service';
import { AmountTierAdminView, WorkflowAdminView, PageResponse } from '../../../core/models/api.models';
import { RateMatrixComponent, MatrixTier, MatrixRow, MatrixAction } from '../../../shared/components/rate-matrix/rate-matrix';
import { RateFilterComponent, FilterState } from '../../../shared/components/rate-filter/rate-filter';
import { buildViewMatrix, buildEnterMatrix, buildApproveMatrix, buildStatusMatrix } from '../../../shared/components/matrix-data-builder';
import { TdCrud } from '../../../lib/organ/td-crud/td-crud';
import { CrudModel } from '../../../lib/organ/td-crud/td-crud.model';
import { TdTableActionModel } from '../../../lib/tissue/td-table-action/td-table-action.model';
import { TdPaginationModel } from '../../../lib/tissue/td-pagination/td-pagination.model';
import { OutputObject } from '../../../lib/share/output-object';

type Tab = 'view' | 'enter' | 'status' | 'approve' | 'history';

@Component({
  selector: 'plra-super-admin-uloc-rates',
  standalone: true,
  imports: [CommonModule, FormsModule, RateMatrixComponent, RateFilterComponent, TdCrud],
  templateUrl: './super-admin-uloc-rates.html',
  styleUrls: ['./super-admin-uloc-rates.css']
})
export class SuperAdminUlocRatesComponent implements OnInit {
  t = inject(TranslationService);
  private api = inject(RateApiService);
  private route = inject(ActivatedRoute);

  tab = signal<Tab>('view');
  tiers = signal<MatrixTier[]>([]);
  viewRows = signal<MatrixRow[]>([]);
  enterRows = signal<MatrixRow[]>([]);
  statusRows = signal<MatrixRow[]>([]);
  approveRows = signal<MatrixRow[]>([]);
  historyCrud = signal<CrudModel | null>(null);

  search = '';
  visibleTierIds: number[] = [];
  saving = signal(false);
  submitting = signal(false);
  approving = signal(false);
  message = signal('');
  messageType = signal<'success' | 'error' | 'info'>('info');

  productName = '';
  private tierData: AmountTierAdminView[] = [];
  private histPage = 0;

  ngOnInit(): void {
    this.api.getProducts({ type: 'ULOC', size: 1 }).subscribe({
      next: res => {
        const p = res.content.find(x => x.type === 'ULOC');
        if (!p) return;
        this.productName = p.name;
        this.api.getAmountTiers(p.name, { unpaged: true }).subscribe({
          next: tierRes => {
            this.tierData = tierRes.content;
            this.tiers.set(tierRes.content.map(t => ({ id: t.id, name: t.name })));
            this.loadView();
            this.loadEnter();
            const initTab = this.route.snapshot.queryParamMap.get('tab');
            if (initTab) { this.switchTab(initTab as any); }
          }
        });
      }
    });
  }

  switchTab(tab: Tab): void {
    this.tab.set(tab);
    this.message.set('');
    switch (tab) {
      case 'view': this.loadView(); break;
      case 'enter': this.loadEnter(); break;
      case 'status': this.loadStatus(); break;
      case 'approve': this.loadApprove(); break;
      case 'history': this.loadHistory(); break;
    }
  }

  /* ═══════ VIEW ═══════ */
  private loadView(): void {
    this.api.getUlocActive({ size: 500 }).subscribe({
      next: r => { this.viewRows.set(buildViewMatrix(this.tierData, r.content, 'ULOC').matrixRows); }
    });
  }

  /* ═══════ ENTER — shows ALL CVP codes, overlays active + drafts ═══════ */
  private loadEnter(): void {
    forkJoin([
      this.api.getUlocActive({ size: 500 }),
      this.api.getUlocDrafts({ status: 'DRAFT', size: 500 }),
      this.api.getCvpCodes({ size: 500 })
    ]).subscribe({
      next: ([activeRes, draftRes, cvpRes]) => {
        const allCvps = cvpRes.content.map(c => ({ id: c.id, name: c.name }));
        const m = buildEnterMatrix(this.tierData, activeRes.content, draftRes.content, 'ULOC', allCvps);
        this.enterRows.set(m.matrixRows);
      }
    });
  }

  /* ═══════ SAVE — CREATE or UPDATE ═══════ */
  saveDrafts(): void {
    const rows = this.enterRows();
    const today = new Date().toISOString().substring(0, 10);
    const nextYear = new Date(Date.now() + 365 * 86400000).toISOString().substring(0, 10);
    const toSave: { draftId: number | null; entityId: number; tierId: number; targetRate: number; floorRate: number; notes: string; startDate: string; expiryDate: string }[] = [];

    for (const row of rows) {
      for (const cell of row.cells) {
        if (cell.newRate !== null && cell.newRate !== undefined) {
          toSave.push({
            draftId: cell.draftId ?? null,
            entityId: row.id, tierId: cell.tierId,
            targetRate: cell.newRate, floorRate: cell.newFloor ?? cell.newRate,
            notes: cell.discretion ?? '',
            startDate: row.effectiveDate || today, expiryDate: row.expiryDate || nextYear,
          });
        }
      }
    }
    if (toSave.length === 0) { this.showMsg('No modified rates to save.', 'info'); return; }
    this.saving.set(true);
    let done = 0, errors = 0;
    for (const item of toSave) {
      const payload = { cvpCodeId: item.entityId, amountTierId: item.tierId, targetRate: item.targetRate, floorRate: item.floorRate, startDate: item.startDate, expiryDate: item.expiryDate, notes: item.notes };
      const obs = item.draftId ? this.api.updateUlocDraft(item.draftId, payload) : this.api.createUlocDraft(payload);
      obs.subscribe({
        next: () => { done++; if (done + errors >= toSave.length) { this.saving.set(false); this.showMsg(`Saved ${done} rate(s).${errors > 0 ? ` ${errors} failed.` : ''}`, errors > 0 ? 'error' : 'success'); this.loadEnter(); } },
        error: (err: any) => { console.error('[PLRA] Save FAILED:', item.draftId, err?.error ?? err); errors++; if (done + errors >= toSave.length) { this.saving.set(false); this.showMsg(`Saved ${done} rate(s). ${errors} failed.`, 'error'); this.loadEnter(); } }
      });
    }
  }

  onEnterAction(event: MatrixAction): void {
    if (event.action === 'save-row') {
      const row = event.rows[0];
      const cells = row.cells.filter(c => c.newRate !== null);
      if (cells.length === 0) return;
      const today = new Date().toISOString().substring(0, 10);
      const nextYear = new Date(Date.now() + 365 * 86400000).toISOString().substring(0, 10);
      this.saving.set(true);
      let done = 0, errors = 0;
      for (const cell of cells) {
        const p = { cvpCodeId: row.id, amountTierId: cell.tierId, targetRate: cell.newRate!, floorRate: cell.newFloor ?? cell.newRate!, startDate: row.effectiveDate || today, expiryDate: row.expiryDate || nextYear, notes: cell.discretion ?? '' };
        const o = cell.draftId ? this.api.updateUlocDraft(cell.draftId, p) : this.api.createUlocDraft(p);
        o.subscribe({
          next: () => { done++; if (done + errors >= cells.length) { this.saving.set(false); this.showMsg(`Row "${row.name}" saved.`, 'success'); this.loadEnter(); } },
          error: () => { errors++; if (done + errors >= cells.length) { this.saving.set(false); this.showMsg(`Row "${row.name}": ${errors} error(s).`, 'error'); } }
        });
      }
    }
  }

  /* ═══════ SUBMIT ═══════ */
  submitSelected(): void {
    const selected = this.enterRows().filter(r => r.selected);
    if (selected.length === 0) { this.showMsg('Select at least one row.', 'info'); return; }
    const draftIds = selected.flatMap(r => r.draftIds);
    if (draftIds.length === 0) { this.showMsg('No drafts to submit.', 'error'); return; }
    this.submitting.set(true);
    let done = 0, errors = 0;
    for (const id of draftIds) {
      this.api.submitUlocDraft(id).subscribe({
        next: () => { done++; if (done + errors >= draftIds.length) { this.submitting.set(false); this.showMsg(`Submitted ${done} draft(s). DRAFT → PENDING.`, 'success'); this.loadEnter(); } },
        error: () => { errors++; if (done + errors >= draftIds.length) { this.submitting.set(false); this.showMsg(`${errors} failed.`, 'error'); } }
      });
    }
  }

  /* ═══════ STATUS — with decision info from workflows ═══════ */
  private loadStatus(): void {
    forkJoin([
      this.api.getUlocDrafts({ size: 500 }),
      this.api.getWorkflows({ size: 500 })
    ]).subscribe({
      next: ([draftRes, wfRes]) => {
        const nonDraft = draftRes.content.filter(d => d.status !== 'DRAFT' && d.status !== 'CANCELLED');
        const ulocWfs = wfRes.content.filter(w => w.rateType === 'ULOC');
        const m = buildStatusMatrix(this.tierData, nonDraft, 'ULOC', ulocWfs);
        this.statusRows.set(m.matrixRows);
      }
    });
  }

  /* ═══════ APPROVE ═══════ */
  private loadApprove(): void {
    forkJoin([
      this.api.getUlocActive({ size: 500 }),
      this.api.getUlocDrafts({ status: 'PENDING', size: 500 })
    ]).subscribe({
      next: ([activeRes, pendingRes]) => {
        this.approveRows.set(buildApproveMatrix(this.tierData, activeRes.content, pendingRes.content, 'ULOC').matrixRows);
      }
    });
  }

  submitDecisions(): void {
    const rows = this.approveRows();
    if (rows.length === 0) { this.showMsg('No pending rates.', 'info'); return; }
    this.approving.set(true);
    let done = 0, errors = 0, total = 0;
    for (const row of rows) {
      for (const draftId of row.draftIds) {
        total++;
        const obs = row.decision === 'APPROVE' ? this.api.approveUlocDraft(draftId, row.comment || undefined) : this.api.rejectUlocDraft(draftId, row.comment || undefined);
        obs.subscribe({
          next: () => { done++; if (done + errors >= total) { this.approving.set(false); this.showMsg(`Processed ${done} decision(s).`, 'success'); this.loadApprove(); } },
          error: () => { errors++; if (done + errors >= total) { this.approving.set(false); this.showMsg(`${errors} failed.`, 'error'); } }
        });
      }
    }
    if (total === 0) { this.approving.set(false); }
  }

  /* ═══════ HISTORY — TdCrud with search/sort/pagination ═══════ */
  private loadHistory(): void {
    forkJoin([
      this.api.getUlocHistory({ size: 200 }),
      this.api.getUlocDrafts({ size: 500 })
    ]).subscribe({
      next: ([histRes, draftRes]) => {
        const approved = draftRes.content.filter(d => d.status === 'APPROVED' || d.status === 'REJECTED');
        const all = [...histRes.content, ...approved];
        const rows = all.map((r: any) => ({
          id: r.id,
          name: r.cvpCode?.name ?? r.subCategory?.name ?? '—',
          tier: r.amountTier?.name ?? '—',
          targetRate: r.targetRate, floorRate: r.floorRate,
          startDate: r.startDate?.substring(0, 10) ?? '', expiryDate: r.expiryDate?.substring(0, 10) ?? '',
          status: r.status, notes: r.notes ?? '',
          createdBy: r.createdBy ?? '', createdOn: r.createdOn?.substring(0, 10) ?? ''
        }));
        this.historyCrud.set(new CrudModel({
          id: 'uloc-history', type: 'table',
          search: { search: { name: 'query', type: 'text', layout: 'icon', label: this.t.get('common.search'), placeholder: this.t.get('common.search'), icon: { iconClass: 'fa-solid fa-magnifying-glass', className: '' }, className: 'form-control' } },
          document: new TdTableActionModel({ className: 'table table-hover', showIconColumn: false, rows }),
          page: new TdPaginationModel({ totalPages: Math.ceil(rows.length / 15), totalElements: rows.length, size: 15, pageNumber: 0, first: true, last: rows.length <= 15, empty: rows.length === 0 })
        }));
      }
    });
  }

  onHistoryOutput(event: OutputObject): void { /* TdCrud handles search/sort/pagination client-side */ }

  /* ═══════ TOOLBAR ═══════ */
  copyNewDown(): void {
    const sel = this.enterRows().filter(r => r.selected);
    if (sel.length < 2) { this.showMsg('Select 2+ rows.', 'info'); return; }
    for (let i = 1; i < sel.length; i++) { for (let j = 0; j < sel[0].cells.length; j++) { if (sel[0].cells[j].newRate !== null) { sel[i].cells[j].newRate = sel[0].cells[j].newRate; sel[i].cells[j].newFloor = sel[0].cells[j].newFloor; } } }
    this.showMsg(`Copied to ${sel.length - 1} row(s).`, 'success');
  }

  copyDiscDown(): void {
    const sel = this.enterRows().filter(r => r.selected);
    if (sel.length < 2) { this.showMsg('Select 2+ rows.', 'info'); return; }
    for (let i = 1; i < sel.length; i++) { for (let j = 0; j < sel[0].cells.length; j++) { if (sel[0].cells[j].discretion) { sel[i].cells[j].discretion = sel[0].cells[j].discretion; } } }
    this.showMsg(`Copied to ${sel.length - 1} row(s).`, 'success');
  }

  onFilter(f: FilterState): void { console.log("[PAGE] onFilter received:", JSON.stringify(f));
    this.search = f.search;
    this.visibleTierIds = f.tierIds.map((id: string) => Number(id));
    const params: Record<string, any> = {};
    if (f.subCategoryIds.length > 0) params['subCategoryIds'] = f.subCategoryIds.join(',');
    console.log('[PAGE] calling API with params:', params); this.api.getUlocActive({ size: 500, ...params }).subscribe({ error: (err: any) => console.error('[PAGE] API error:', err),
      next: (r: any) => { console.log('[PAGE] API response:', r.content.length, 'rates'); this.viewRows.set(buildViewMatrix(this.tierData, r.content, 'ULOC').matrixRows); }
    });
  }

  private showMsg(msg: string, type: 'success' | 'error' | 'info'): void { this.message.set(msg); this.messageType.set(type); }
}
